Econis-Labs Demo Kit Node Utility

Purpose:
GENERATE = Change the node last 4 bytes of DeviceEUI (first 4 bytes are always "AA555A00"
DevAddr PATCH = Patch the web asigned "Device Address" and change frequency band to TTN-MyDevices. 
(GENERATE File name <Device-EUI>.HEX", patch filename is "<Device-EUI>-TTN.HEX"

The generated HEX will be loaded via Serial Port (J2 Connector) using a 3.3V FTDI Cable 
Download application used "STMFlashLoader Demo" from ST website.

Both NwkKey and AppKey is set to "AA555A00<4byte_DeviceEUI>AA555A00<4byte_DevEUI>".
Application EUI will is set to "AA555A00<4byte_DeviceEUI>"

